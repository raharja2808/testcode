using Elastic.Apm.AspNetCore;
using Elastic.Apm.DiagnosticSource;
using Elastic.Apm.SqlClient;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.ResponseCompression;
using Pacman.Vendor.Polo.API;
using Pacman.Vendor.Polo.API.Doc;
using System.Net;
using System.Net.Http.Headers;

// ---------------------------------------------------------------------------------------------------------------------------------------------------
// Builder
// ---------------------------------------------------------------------------------------------------------------------------------------------------
var builder = WebApplication.CreateBuilder(args);

builder.Configuration.SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
});
builder.Services.Configure<GzipCompressionProviderOptions>(opt => opt.Level = System.IO.Compression.CompressionLevel.Fastest);
builder.Services.AddResponseCompression();

// ---------------------------------------------------------------------------------------------------------------------------------------------------
// Builder - Add API Endpoint
// ---------------------------------------------------------------------------------------------------------------------------------------------------
builder.Services.AddHttpClient("AdminSM", client =>
{
    client.BaseAddress = new Uri(builder.Configuration.GetSection("API:AdminSM").Value);
    client.DefaultRequestHeaders.AcceptEncoding.Add(new StringWithQualityHeaderValue("gzip"));
    client.Timeout = TimeSpan.FromMinutes(5);
}).ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler()
{
    AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate
}).SetHandlerLifetime(Timeout.InfiniteTimeSpan);


// ---------------------------------------------------------------------------------------------------------------------------------------------------
// App
// ---------------------------------------------------------------------------------------------------------------------------------------------------
var app = builder.Build();

if (builder.Configuration.GetSection("ElasticApm:Active").Value == "true")
{
    app.UseElasticApm(builder.Configuration,
        new HttpDiagnosticsSubscriber(),
    new SqlClientDiagnosticSubscriber());
}
app.UseResponseCompression();
app.UseForwardedHeaders();


// ---------------------------------------------------------------------------------------------------------------------------------------------------
// Mapping
// ---------------------------------------------------------------------------------------------------------------------------------------------------
app.MapGet("/", () => "PG Vendor Polo API");
app.MapGet("/healthz.api", () => "OK");
app.MapGet("/doc", () => DocAllAPI.Write());
app.MapWhen(
    context => context.Request.Path.ToString().EndsWith(".api"),
    appBranch =>
    {
        appBranch.UseAPIHandler();
    });

// ---------------------------------------------------------------------------------------------------------------------------------------------------
// Start
// ---------------------------------------------------------------------------------------------------------------------------------------------------
app.Run(app.Configuration["HostingURL"]);
