﻿namespace Pacman.Vendor.Polo.API.Output
{
    public class Notification : OutputBase
    {
        public NotificationContent Content { get; set; }

        public Notification()
        {
            this.Content = new NotificationContent();
        }
    }

    public class NotificationContent
    {
        public string MerchantTransactionID { get; set; }
        public string Status { get; set; }
        public string CallbackResponse { get; set; }
    }
}
