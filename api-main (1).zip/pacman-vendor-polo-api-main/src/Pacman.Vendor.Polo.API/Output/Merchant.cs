﻿namespace Pacman.Vendor.Polo.API.Output
{
    public class Merchant : OutputBase
    {
        public MerchantContent Content { get; set; }

        public Merchant()
        {
            Content = new MerchantContent();
        }
    }

    public class MerchantContent
    {
        public string MerchantID { get; set; }
        public string MerchantTransactionID { get; set; }
        public string PGMerchantID { get; set; }
        public string PGMerchantPassKey { get; set; }
        public string MerchantPaymentChannel { get; set; }
        public string MerchantPaymentChannelVendor { get; set; }
        public string RequestURLFundIn { get; set; }
        public string ReturnURLFundIn { get; set; }
        public string RequestURLFundOut { get; set; }
        public string BankCode { get; set; }
        public string BankCodeVendor { get; set; }
    }
}
