﻿namespace Pacman.Vendor.Polo.API.Output
{
    public class XPayFundOutQuery
    {
        public Int32 TotalItem { get; set; }
        public List<XPayFundOutQueryData> Data { get; set; }
        public string ErrorMessage { get; set; }

        public XPayFundOutQuery()
        {
            Data = new List<XPayFundOutQueryData>();
        }
    }

    public class XPayFundOutQueryData
    {
        public string PGTransactionID { get; set; }
        public string MerchantTransactionID { get; set; }
        public string MerchantID { get; set; }
        public string Currency { get; set; }
        public decimal? Amount { get; set; }
        public decimal? FundOutFee { get; set; }
        public decimal? FundOutFailFee { get; set; }
        public string Status { get; set; }
    }
}
