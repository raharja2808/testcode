﻿namespace Pacman.Vendor.Polo.API.Output
{
    public class FundQuery : OutputBase
    {
        public FundQueryContent Content { get; set; }

        public FundQuery()
        {
            Content = new FundQueryContent();
        }

        public FundQuery(Exception ex) : base(ex)
        {
            Content = new FundQueryContent();
        }
    }

    public class FundQueryContent
    {
        public string MerchantTransactionID { get; set; }
        public string PGTransactionD { get; set; }
        public decimal Amount { get; set; }
        public decimal Fee { get; set; }
        public decimal FundOutFee { get; set; }
        public decimal FundOutFailFee { get; set; }
        public DateTime? DateRequest { get; set; }
        public DateTime? DateCompleted { get; set; }
        public string Status { get; set; }
        public string BankCode { get; set; }
        public string BankName { get; set; }
        public string DepositType { get; set; }
        public string Currency { get; set; }

    }
}
