﻿namespace Pacman.Vendor.Polo.API.Output
{
    public class FundOut : OutputBase
    {
        public string ErrorCode { get; set; }
        public FundOutContent Content { get; set; }

        public FundOut()
        {
            Content = new FundOutContent();
        }

        public FundOut(Exception ex) : base(ex)
        {
            Content = new FundOutContent();
        }
    }

    public class FundOutContent
    {
        public string PGTransactionID { get; set; }
        public string MerchantTransactionID { get; set; }
        public string Currency { get; set; }
        public decimal Amount { get; set; }
        public decimal Fee { get; set; }
        public string BankCode { get; set; }
        public string Status { get; set; }
    }
}
