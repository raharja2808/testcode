﻿namespace Pacman.Vendor.Polo.API.Output
{
    public class XPayFundInQuery
    {
        public Int32 TotalItem { get; set; }
        public List<XPayFundInQueryData> Data { get; set; }
        public string ErrorMessage { get; set; }

        public XPayFundInQuery()
        {
            Data = new List<XPayFundInQueryData>();
        }
    }

    public class XPayFundInQueryData
    {
        public string PGTransID { get; set; }
        public string PGMerchantID { get; set; }
        public string MerchantTransactionID { get; set; }
        public string MerchantID { get; set; }
        public string Currency { get; set; }
        public string BankCode { get; set; }
        public string BankName { get; set; }
        public decimal? Amount { get; set; }
        public decimal? Fee { get; set; }
        public string DepositType { get; set; }
        public string Status { get; set; }
        public DateTime? DateRequest { get; set; }
        public DateTime? DateCompleted { get; set; }
    }

}
