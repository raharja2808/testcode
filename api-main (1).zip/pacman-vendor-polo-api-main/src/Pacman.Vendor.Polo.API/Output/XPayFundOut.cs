﻿namespace Pacman.Vendor.Polo.API.Output
{
    public class XPayFundOut
    {
        public string MerchantTransactionID { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
        public string Sign { get; set; }
        public string PGTransactionID { get; set; }
        public string Currency { get; set; }
        public decimal Amount { get; set; }
        public decimal? Fee { get; set; }
        public string BankCode { get; set; }
        public string Status { get; set; }
    }
}
