﻿namespace Pacman.Vendor.Polo.API.Output
{
    public class XPayBalance
    {
        public Int32 TotalItem { get; set; }

        public List<XPayBalanceData> Data { get; set; }

        public XPayBalance()
        {
            Data = new List<XPayBalanceData>();
        }
    }

    public class XPayBalanceData
    {
        public string Currency { get; set; }
        public decimal BalanceAvailable { get; set; }
        public decimal BalanceCurrent { get; set; }
        public string Status { get; set; }
    }
}
