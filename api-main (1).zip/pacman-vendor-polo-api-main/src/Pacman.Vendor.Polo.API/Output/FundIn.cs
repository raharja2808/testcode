﻿namespace Pacman.Vendor.Polo.API.Output
{
    public class FundIn : OutputBase
    {
        public FundInContent Content { get; set; }

        public FundIn()
        {
            Content = new FundInContent();
        }

        public FundIn(Exception ex) : base(ex)
        {
            Content = new FundInContent();
        }
    }

    public class FundInContent
    {
        public string MerchantTransactionID { get; set; }
        public decimal Amount { get; set; }
        public string Currency { get; set; }
        public string BankCode { get; set; }
    }
}
