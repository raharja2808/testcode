﻿namespace Pacman.Vendor.Polo.API.Output
{
    public class PGBalance : OutputBase
    {
        public PGBalanceContent Content { get; set; }

        public PGBalance()
        {
            Content = new PGBalanceContent();
        }

        public PGBalance(Exception ex) : base(ex)
        {
            Content = new PGBalanceContent();
        }
    }

    public class PGBalanceContent
    {
        public decimal MerchantBalance { get; set; }
    }
}
