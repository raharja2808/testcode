﻿using Pacman.Vendor.Polo.API.Helper;
using System.Reflection;

namespace Pacman.Vendor.Polo.API.Services
{
    public class FundOutQuery: BaseService
    {
        private readonly APICallHelper api;

        public FundOutQuery(HttpContext httpContext, IHttpClientFactory httpClientFactory) : base(httpContext)
        {
            this.api = new APICallHelper(httpClientFactory);
        }

        public override async Task<string> GetResponse()
        {
            string retVal;
            var methodType = MethodBase.GetCurrentMethod().DeclaringType;
            await this.SetLoggerName(methodType.FullName);
            this.GrayLogMessage.ShortMessage = methodType.FullName;

            try
            {
                if (this.IsJSONStringInputEmpty)
                {
                    retVal = this.SetErrorJSONStringEmpty();
                    this.SetLoggerWarn();
                }
                else
                {
                    var tuple = this.ParsingJSONStringInput<Model.Request>();
                    if (tuple.Item1)
                    {
                        var data = tuple.Item3;

                        retVal = this.ProcessResult(await PGHelper.FundOutQuery(api, data));
                    }
                    else
                    {
                        retVal = tuple.Item2;
                        this.SetLoggerError();
                    }

                }
            }
            catch (Exception ex)
            {
                retVal = this.SetErrorUnknownError(ex);
                this.SetLoggerError();
            }

            return retVal;
        }
    }
}
