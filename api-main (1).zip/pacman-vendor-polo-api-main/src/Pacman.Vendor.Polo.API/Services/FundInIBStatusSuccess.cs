﻿using Pacman.Vendor.Polo.API.Helper;
using System.Reflection;

namespace Pacman.Vendor.Polo.API.Services
{
    public class FundInIBStatusSuccess : BaseService
    {
        public FundInIBStatusSuccess(HttpContext httpContext) : base(httpContext)
        {
        }

        public override async Task<string> GetResponse()
        {
            string retVal = string.Empty;
            var methodType = MethodBase.GetCurrentMethod().DeclaringType;
            await this.SetLoggerName(methodType.FullName);
            this.GrayLogMessage.ShortMessage = methodType.FullName;
            var log = new Model.Log { Currency = "IDR", Method = "CALLBACK_FUND_IN", Request = this.JSONStringInput };

            try
            {
                if (this.IsJSONStringInputEmpty)
                {
                    retVal = this.SetErrorJSONStringEmpty();
                    this.SetLoggerWarn();
                }
                else
                {
                    var tuple = this.ParsingJSONStringInput<Model.FundInStatus>();
                    if (tuple.Item1)
                    {
                        var data = tuple.Item3;
                        data.Status = "SUCCESS";
                        data.Reason = string.Empty;

                        retVal = this.ProcessResult(await PGHelper.FundInIBStatus(data));
                        log.Response = retVal;
                    }
                    else
                    {
                        retVal = tuple.Item2;
                        this.SetLoggerError();
                    }
                }
            }
            catch (Exception ex)
            {
                this.SetLoggerError();
                log.Response = $"{ex.Message} {ex.StackTrace}";
            }
            finally
            {
                Entities.Callback.InsertLog(log);
            }

            return retVal;
        }
    }
}
