﻿using Pacman.Vendor.Polo.API.Entities;
using System.Diagnostics;

namespace Pacman.Vendor.Polo.API.Services
{
    public abstract class BaseService
    {
        #region -= Fields =-
        private Logger logger;
        private readonly Stopwatch stopwatch;
        #endregion

        #region -= Properties =-
        protected HttpContext Context;
        protected string JSONStringInput;
        protected readonly Dictionary<string, string> QueryStringInput;
        protected GelfMessage GrayLogMessage { get { return this.logger.GelfMessage; } }
        protected bool IsJSONStringInputEmpty;
        #endregion

        #region -= Constructor =-
        public BaseService(HttpContext httpContext)
        {
            stopwatch = Stopwatch.StartNew();
            Context = httpContext;
            QueryStringInput = new Dictionary<string, string>();
            foreach (var q in this.Context.Request.Query)
            {
                var key = q.Key;
                var value = string.IsNullOrEmpty(q.Value) ? string.Empty : q.Value.ToString();
                QueryStringInput.Add(key, value);
            }
        }
        #endregion

        #region -= Methods =-
        private async Task Init()
        {
            using StreamReader sr = new(Context.Request.Body);
            JSONStringInput = await sr.ReadToEndAsync();

            IsJSONStringInputEmpty = (string.IsNullOrEmpty(JSONStringInput));
        }

        public abstract Task<string> GetResponse();

        private void SetInitGrayLogMessage()
        {
            this.GrayLogMessage.RawJSONInput = JSONStringInput;
            this.GrayLogMessage.ServerIP = this.Context.Connection.LocalIpAddress.ToString();
            this.GrayLogMessage.RemoteIP = this.Context.Connection.RemoteIpAddress.ToString();
            this.GrayLogMessage.URL = string.Format("{0}://{1}{2}", this.Context.Request.Scheme, this.Context.Request.Host, this.Context.Request.Path);
        }

        #region -= Error =-
        protected string SetErrorJSONStringEmpty()
        {
            var err = new { ResultCode = 40000, ErrorMessage = "Unknown Error", Result = "" };
            var errJSON = Helper.JSONHelper.Serialize(err);

            GrayLogMessage.ErrorCode = err.ResultCode;
            GrayLogMessage.ErrorMessage = err.ErrorMessage;

            return errJSON;
        }

        protected string SetErrorUnknownError(Exception ex)
        {
            var err = new { ResultCode = 40000, ErrorMessage = "Unknown Error", Result = "" };

            GrayLogMessage.ErrorCode = err.ResultCode;
            GrayLogMessage.ErrorMessage = err.ErrorMessage;
            GrayLogMessage.Exception = ex;

            return Helper.JSONHelper.Serialize(err);
        }

        private void SetErrorBL(Int32 errorCode, string errorMessage)
        {
            this.GrayLogMessage.ErrorCode = errorCode;
            this.GrayLogMessage.ErrorMessage = errorMessage;
            //this.GrayLogMessage.ShortMessage = $"{this.GrayLogMessage.ShortMessage}: {errorMessage}";
        }

        private void SetErrorBL(Int32 errorCode, string errorMessage, Exception ex)
        {
            this.GrayLogMessage.ErrorCode = errorCode;
            this.GrayLogMessage.ErrorMessage = errorMessage;
            this.GrayLogMessage.Exception = ex;
            //this.GrayLogMessage.ShortMessage = $"{this.GrayLogMessage.ShortMessage}: {errorMessage}";
        }
        #endregion

        protected Tuple<bool, string, T> ParsingJSONStringInput<T>()
        {
            try
            {
                var model = Helper.JSONHelper.Deserialize<T>(this.JSONStringInput);

                Type objTracking = model.GetType();
                object tracking = objTracking.GetProperty("TrackingCode").GetValue(model);

                if (tracking != null)
                    this.GrayLogMessage.TrackingCode = tracking.ToString();

                Type objStampUser = model.GetType();
                object stampUser = objStampUser.GetProperty("StampUser").GetValue(model);

                if (stampUser != null)
                    this.GrayLogMessage.StampUser = stampUser.ToString();

                return Tuple.Create<bool, string, T>(true, string.Empty, model);
            }
            catch (Exception ex)
            {
                var err = new { ResultCode = 40000, ErrorMessage = "Unknown Error", Result = "" };
                var errJSON = Helper.JSONHelper.Serialize(err);

                GrayLogMessage.ErrorCode = err.ResultCode;
                GrayLogMessage.ErrorMessage = err.ErrorMessage;
                GrayLogMessage.Exception = ex;

                return Tuple.Create<bool, string, T>(false, errJSON, default);
            }
        }

        protected void SetGrayLogNewFields(string key, string value)
        {
            if (this.GrayLogMessage.ListFields == null)
                this.GrayLogMessage.ListFields = new Dictionary<string, string>();

            this.GrayLogMessage.ListFields.Add(key, value);
        }

        protected string ProcessResult(Helper.BaseHelper helper)
        {
            string retVal = helper.JSONString;

            this.GrayLogMessage.Output = retVal;
            this.GrayLogMessage.SQLDetail = helper.SQLDetail;
            this.GrayLogMessage.ProcedureFlow = helper.ProcedureFlow;
            this.GrayLogMessage.StampUser = helper.StampUser;
            this.GrayLogMessage.SQLException = helper.SQLException;
            this.GrayLogMessage.SQLElapsed = helper.SQLElapsed;
            if (!string.IsNullOrEmpty(helper.ShortMessage))
            {
                this.GrayLogMessage.ProviderCode = helper.ProviderCode;
                this.GrayLogMessage.ShortMessage = helper.ShortMessage;
            }

            if (helper.IsError)
            {
                if (helper.IsThrowException)
                {
                    this.SetErrorBL(helper.ResultCode, helper.ErrorMessage, helper.Exception);
                    this.SetLoggerError();
                }
                else
                {
                    this.SetErrorBL(helper.ResultCode, helper.ErrorMessage);
                    this.SetLoggerWarn();
                }
            }
            else
            {
                this.GrayLogMessage.FullMessage = retVal;
                this.SetLoggerInfo();
            }

            return retVal;
        }

        #region -= Logger =-
        protected async Task SetLoggerName(string name)
        {
            this.logger = new Logger(name);
            await Init();
            SetInitGrayLogMessage();
        }

        protected void SetLoggerInfo()
        {
            if (this.logger != null)
            {
                stopwatch.Stop();
                this.GrayLogMessage.ElapsedTime = stopwatch.Elapsed.TotalSeconds;
                this.logger.SetInfo();
            }
        }

        protected void SetLoggerWarn()
        {
            if (this.logger != null)
            {
                stopwatch.Stop();
                this.GrayLogMessage.ElapsedTime = stopwatch.Elapsed.TotalSeconds;
                this.logger.SetWarn();
            }
        }

        protected void SetLoggerError()
        {
            if (this.logger != null)
            {
                stopwatch.Stop();
                this.GrayLogMessage.ElapsedTime = stopwatch.Elapsed.TotalSeconds;
                this.logger.SetError();
            }
        }
        #endregion
        #endregion
    }
}
