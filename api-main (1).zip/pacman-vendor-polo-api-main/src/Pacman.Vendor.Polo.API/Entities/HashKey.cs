﻿using System.Data.SqlClient;

namespace Pacman.Vendor.Polo.API.Entities
{
    public class HashKey
    {
        public string KeyConfirmation { get; set; }

        public static HashKey GetKeys(string currency)
        {
            var obj = new HashKey();
            var retVal = new BasicEntity(currency);

            _ = retVal.SQLCommandBuilder("spPGHashKey");

            using (SqlDataReader reader = retVal.ExecReader())
            {
                while (reader.Read())
                {
                    obj.KeyConfirmation = (reader.IsDBNull(0)) ? string.Empty : reader.GetString(0);
                }
                reader.Close();
            }

            retVal.Close();

            return obj;
        }
    }
}
