﻿using System.Data.SqlClient;

namespace Pacman.Vendor.Polo.API.Entities
{
    public class RequestResponseLog
    {
        public static BasicEntity Insert(Model.APICall data, Output.OutputBase obj)
        {
            var retVal = new BasicEntity(data.Currency);

            retVal.AddParameter("@request", data.Request);
            retVal.AddParameter("@response", data.Response);
            data.SqlDetail = retVal.SQLCommandBuilder("spAPICallLog");

            using (SqlDataReader reader = retVal.ExecReader())
            {
                while (reader.Read())
                {
                    obj.ResultCode = (reader.IsDBNull(0)) ? 0 : reader.GetInt32(0);
                    obj.ErrorMessage = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                    retVal.ResultCode = obj.ResultCode;
                }

                reader.Close();
            }

            retVal.Close();

            return retVal;
        }
    }
}
