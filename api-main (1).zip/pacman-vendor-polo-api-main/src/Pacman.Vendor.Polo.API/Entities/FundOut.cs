﻿using System.Data.SqlClient;

namespace Pacman.Vendor.Polo.API.Entities
{
    public class FundOut
    {
        public static BasicEntity Pending(Model.Request data, Output.OutputBase obj)
        {
            var retVal = new BasicEntity(data.Currency);

            retVal.AddParameter("@pg_merchant_id", data.PGMerchantID);
            retVal.AddParameter("@currency", data.Currency);
            retVal.AddParameter("@merchant_transaction_id", data.MerchantTransactionID);
            retVal.AddParameter("@merchant_id", data.MerchantID);
            retVal.AddParameter("@amount", data.Amount);
            retVal.AddParameter("@payment_channel_id", data.MerchantPaymentChannel);
            retVal.AddParameter("@payment_channel_id_vendor", data.PGMerchantPaymentChannel);
            retVal.AddParameter("@bank_code", data.BankCode);
            retVal.AddParameter("@bank_code_vendor", data.BankCodeVendor);
            retVal.AddParameter("@account_no", data.BankAccountNo);
            retVal.AddParameter("@account_name", data.BankAccountName);
            retVal.AddParameter("@bank_province", data.BankBranch);
            retVal.AddParameter("@bank_city", data.BankCity);
            retVal.AddParameter("@bank_branch", data.BankProvince);
            retVal.AddParameter("@transaction_date", data.DateRequest);
            data.SqlDetail = retVal.SQLCommandBuilder("spPGXPayFundOutPending");

            using (SqlDataReader reader = retVal.ExecReader())
            {
                while (reader.Read())
                {
                    obj.ResultCode = (reader.IsDBNull(0)) ? 0 : reader.GetInt32(0);
                    obj.ErrorMessage = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                    retVal.ResultCode = obj.ResultCode;
                }

                reader.Close();
            }

            retVal.Close();

            return retVal;
        }

        public static BasicEntity PendingUpdate(Model.Request data, Output.OutputBase obj)
        {
            var retVal = new BasicEntity(data.Currency);

            retVal.AddParameter("@merchant_transaction_id", data.MerchantTransactionID);
            retVal.AddParameter("@pg_transaction_id", data.PGTransactionID);
            retVal.AddParameter("@fee", data.Fee);
            data.SqlDetail = retVal.SQLCommandBuilder("spPGXPayFundOutPendingUpdate");

            using (SqlDataReader reader = retVal.ExecReader())
            {
                while (reader.Read())
                {
                    obj.ResultCode = (reader.IsDBNull(0)) ? 0 : reader.GetInt32(0);
                    obj.ErrorMessage = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                    retVal.ResultCode = obj.ResultCode;
                }

                reader.Close();
            }

            retVal.Close();

            return retVal;
        }

        public static BasicEntity PendingStatus(Model.PGStatus data, Output.Notification obj)
        {
            var retVal = new BasicEntity(data.Currency);

            retVal.AddParameter("@merchant_transaction_id", data.MerchantTransactionID);
            retVal.AddParameter("@pg_transaction_id", data.PGTransactionID);
            retVal.AddParameter("@status", data.Status);
            retVal.AddParameter("@error_code", data.ErrorCode);
            retVal.AddParameter("@error_description", data.ErrorDescription);
            retVal.AddParameter("@trigger_by", data.TriggerBy);
            retVal.AddParameter("@transaction_note", data.TransactionNote);
            data.SqlDetail = retVal.SQLCommandBuilder("spPGXPayFundOutPendingStatus");

            using (SqlDataReader reader = retVal.ExecReader())
            {
                while (reader.Read())
                {
                    obj.ResultCode = (reader.IsDBNull(0)) ? 0 : reader.GetInt32(0);
                    obj.ErrorMessage = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                    retVal.ResultCode = obj.ResultCode;
                }

                if (obj.ResultCode == 1)
                {
                    reader.NextResult();
                    while (reader.Read())
                    {
                        obj.Content.MerchantTransactionID = (reader.IsDBNull(0)) ? string.Empty : reader.GetString(0);
                        obj.Content.Status = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                        obj.Content.CallbackResponse = (reader.IsDBNull(2)) ? string.Empty : reader.GetString(2);
                    }
                }
                reader.Close();
            }

            retVal.Close();

            return retVal;
        }
    }
}
