﻿using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Xml;


namespace Pacman.Vendor.Polo.API.Entities
{
    public class Util
    {
        private static HashKey objKey;

        public static HashKey GetKeys(string currency)
        {
            objKey ??= HashKey.GetKeys(currency);

            return objKey;
        }

        public static string MD5Hash(string input)
        {
            Console.WriteLine(input);
            using var md5 = MD5.Create();
            var result = md5.ComputeHash(Encoding.ASCII.GetBytes(input));
            var sb = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
                sb.Append(result[i].ToString("X2").ToUpper());
            return sb.ToString();
        }

        public static string SHA512Hash(string input)
        {
            using var hashFunc = SHA512.Create();
            var result = hashFunc.ComputeHash(Encoding.UTF8.GetBytes(input));
            var sb = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
                sb.Append(result[i].ToString("X2").ToUpper());
            return sb.ToString();
        }

        public static string SHA1Hash(string input)
        {
            using var hashFunc = SHA1.Create();
            var result = hashFunc.ComputeHash(Encoding.UTF8.GetBytes(input));
            var sb = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
                sb.Append(result[i].ToString("X2").ToUpper());
            return sb.ToString();
        }

        public static string Base64Encoded(string input)
        {
            return Convert.ToBase64String(Encoding.UTF8.GetBytes(input));
        }

        public static DateTime UnixTimeToDate(Int64 epoch)
        {
            return new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(epoch);
        }

        public static DateTime UnixTimeToDateMiliSecond(Int64 epoch)
        {
            return new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddMilliseconds(epoch);
        }

        public static string CreateSignatureConfirmation(string currency, string input)
        {
            return Util.SHA512Hash($"{input}{GetKeys(currency).KeyConfirmation}");
        }

        public static string URLEncode(string input)
        {
            return System.Web.HttpUtility.UrlEncode(input).ToLower();
        }

        public static string FundStatus(string input)
        {
            var retVal = string.Empty;
            switch (input)
            {
                case "000": { retVal = "SUCCESS"; break; }
                case "111": { retVal = "FAILED"; break; }
                case "001": { retVal = "PENDING"; break; }
                case "002": { retVal = "BANK_PAYMENT_SUCCESS"; break; }
                case "112": { retVal = "REJECTED"; break; }
            }
            return retVal;
        }

        public static string BankMapping(string input, string mode)
        {
            var retVal = string.Empty;

            if (mode.Equals("DirectDebit"))
            {
                switch (input)
                {
                    case "BAY": { retVal = "BAY"; break; }
                    case "KTB": { retVal = "KTB"; break; }
                    case "SIAM": { retVal = "SCB"; break; }
                }
            }
            else if (mode.Equals("P2P"))
            {
                switch (input)
                {
                    // THB
                    case "BAY": { retVal = "BAY.FT"; break; }
                    case "BKK": { retVal = "BBL.FT"; break; }
                    case "GSB": { retVal = "GSB.FT"; break; }
                    case "KBA": { retVal = "KBANK.FT"; break; }
                    case "KTB": { retVal = "KTB.FT"; break; }
                    case "SIAM": { retVal = "SCB.FT"; break; }
                    case "TTB": { retVal = "TMB.FT"; break; }

                    // MYR
                    case "MBB": { retVal = "MBB"; break; }
                    case "PBB": { retVal = "PBB"; break; }
                    case "HLB": { retVal = "HLB"; break; }
                    case "CIMB": { retVal = "CIMB"; break; }
                    case "RHB": { retVal = "RHB"; break; }
                    case "AMB": { retVal = "AMB"; break; }
                    case "BIM": { retVal = "BIM"; break; }
                }
            }
            else if (mode.Equals("FPX"))
            {
                switch (input)
                {
                    // MYR
                    case "MBB": { retVal = "MBB.FPX"; break; }
                    case "HLB": { retVal = "HLB.FPX"; break; }
                    case "RHB": { retVal = "RHB.FPX"; break; }
                    case "AMB": { retVal = "AMB.FPX"; break; }
                    case "PBB": { retVal = "PBB.FPX"; break; }
                    case "BSN": { retVal = "BSN.FPX"; break; }
                    case "CIMB": { retVal = "CIMB.FPX"; break; }
                    case "ALB": { retVal = "ALB.FPX"; break; }
                    case "SDCB": { retVal = "SDCBM.FPX"; break; }
                    case "HSBC": { retVal = "HSBC.FPX"; break; }
                    case "OCBC": { retVal = "OCBC.FPX"; break; }
                    case "UOB": { retVal = "UOB.FPX"; break; }
                }
            }
            else if (mode.Equals("Payout"))
            {
                switch (input)
                {
                    case "KTB": { retVal = "KTB"; break; }
                    case "SIAM": { retVal = "SCB"; break; }
                    case "BKK": { retVal = "BBL"; break; }
                    case "KBA": { retVal = "KBANK"; break; }
                    case "BAY": { retVal = "BAY"; break; }
                    case "UOB": { retVal = "UOB"; break; }
                    case "SDCB": { retVal = "SDCB"; break; }
                    case "LHB": { retVal = "LHB"; break; }
                    case "GSB": { retVal = "GSB"; break; }
                    case "GHB": { retVal = "GHB"; break; }
                    case "TTB": { retVal = "TTB"; break; }
                }
            }

            return retVal;
        }

    }
}
