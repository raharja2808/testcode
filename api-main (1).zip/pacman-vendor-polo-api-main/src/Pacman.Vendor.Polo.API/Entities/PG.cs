﻿using System.Data.SqlClient;

namespace Pacman.Vendor.Polo.API.Entities
{
    public class PG
    {
        public static BasicEntity Info(Model.PGBase data, Output.Merchant obj)
        {
            var retVal = new BasicEntity(data.Currency);

            retVal.AddParameter("@pg_merchant_id", data.PGMerchantID);
            retVal.AddParameter("@currency", data.Currency);
            data.SqlDetail = retVal.SQLCommandBuilder("spPGXPayInfo");

            using (SqlDataReader reader = retVal.ExecReader())
            {
                while (reader.Read())
                {
                    obj.ResultCode = (reader.IsDBNull(0)) ? 0 : reader.GetInt32(0);
                    obj.ErrorMessage = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                    retVal.ResultCode = obj.ResultCode;
                }

                if (retVal.ResultCode == 1)
                {
                    reader.NextResult();
                    while (reader.Read())
                    {
                        obj.Content.PGMerchantID = (reader.IsDBNull(0)) ? string.Empty : reader.GetString(0);
                        obj.Content.PGMerchantPassKey = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                    }
                }

                reader.Close();
            }

            retVal.Close();

            return retVal;
        }

        public static BasicEntity InfoByMerchantTransactionID(Model.Request data, Output.Merchant obj)
        {
            var retVal = new BasicEntity(data.Currency);

            retVal.AddParameter("@merchant_transaction_id", data.MerchantTransactionID);
            data.SqlDetail = retVal.SQLCommandBuilder("spPGXPayInfoByTransactionID");

            using (SqlDataReader reader = retVal.ExecReader())
            {
                while (reader.Read())
                {
                    obj.ResultCode = (reader.IsDBNull(0)) ? 0 : reader.GetInt32(0);
                    obj.ErrorMessage = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                    retVal.ResultCode = obj.ResultCode;
                }

                if (retVal.ResultCode == 1)
                {
                    reader.NextResult();
                    while (reader.Read())
                    {
                        obj.Content.PGMerchantID = (reader.IsDBNull(0)) ? string.Empty : reader.GetString(0);
                        obj.Content.PGMerchantPassKey = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                    }
                }

                reader.Close();
            }

            retVal.Close();

            return retVal;
        }

        public static BasicEntity InfoByPGTransactionID(Model.Request data, Output.Merchant obj)
        {
            var retVal = new BasicEntity(data.Currency);

            retVal.AddParameter("@pg_transaction_id", data.PGTransactionID);
            data.SqlDetail = retVal.SQLCommandBuilder("spPGXPayInfoByPGTransactionID");

            using (SqlDataReader reader = retVal.ExecReader())
            {
                while (reader.Read())
                {
                    obj.ResultCode = (reader.IsDBNull(0)) ? 0 : reader.GetInt32(0);
                    obj.ErrorMessage = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                    retVal.ResultCode = obj.ResultCode;
                }

                if (retVal.ResultCode == 1)
                {
                    reader.NextResult();
                    while (reader.Read())
                    {
                        obj.Content.PGMerchantID = (reader.IsDBNull(0)) ? string.Empty : reader.GetString(0);
                        obj.Content.PGMerchantPassKey = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                        obj.Content.MerchantTransactionID = (reader.IsDBNull(2)) ? string.Empty : reader.GetString(2);
                    }
                }

                reader.Close();
            }

            retVal.Close();

            return retVal;
        }
    }
}
