﻿using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace Pacman.Vendor.Polo.API.Entities
{
    public class BasicEntity
    {
        #region -= Fields =-
        private List<SqlParameter> Parameters = new();
        private DateTime timeStart;
        private DateTime timeStop;
        private string storedProcedureName;
        private string connName;
        #endregion

        #region -= Properties =-
        public Int32 ResultCode { get; set; }
        public string SQLDetail { get; set; }
        public string ConnectionString
        {
            get
            {
                string retVal;
                switch (connName)
                {
                    case "IDR": { retVal = Handler.APIHandler.appConfig.GetSection("ConnectionStrings:Service").Value; break; }
                    case "THB": { retVal = Handler.APIHandler.appConfig.GetSection("ConnectionStrings:ServiceTHB").Value; break; }
                    case "VND": { retVal = Handler.APIHandler.appConfig.GetSection("ConnectionStrings:ServiceVND").Value; break; }
                    case "MYR": { retVal = Handler.APIHandler.appConfig.GetSection("ConnectionStrings:ServiceMYR").Value; break; }
                    case "SGD": { retVal = Handler.APIHandler.appConfig.GetSection("ConnectionStrings:ServiceSGD").Value; break; }
                    case "KRW": { retVal = Handler.APIHandler.appConfig.GetSection("ConnectionStrings:ServiceKRW").Value; break; }
                    case "JPY": { retVal = Handler.APIHandler.appConfig.GetSection("ConnectionStrings:ServiceJPY").Value; break; }
                    case "PHP": { retVal = Handler.APIHandler.appConfig.GetSection("ConnectionStrings:ServicePHP").Value; break; }
                    default: { retVal = Handler.APIHandler.appConfig.GetSection("ConnectionStrings:Service").Value; break; }
                }
                return retVal;
            }
        }
        public Int32 Total { get; set; }
        public Int32 SqlTimeOut { get; set; }
        public double SQLElapsed => timeStop.Subtract(timeStart).TotalSeconds;
        #endregion

        #region -= Constructor =-
        public BasicEntity()
        {
            this.ResultCode = 0;
            this.SqlTimeOut = 0;
            this.timeStart = DateTime.Now;
            this.connName = "IDR";
        }

        public BasicEntity(string currency)
        {
            this.ResultCode = 0;
            this.SqlTimeOut = 0;
            this.timeStart = DateTime.Now;
            this.connName = currency;
        }
        #endregion

        #region -= Methods =-
        public string SQLCommandBuilder(string spName)
        {
            StringBuilder sb = new();
            this.storedProcedureName = spName;
            var dbName = string.Empty;

            using (var sqlServerConn = new SqlConnection(ConnectionString))
            {
                dbName = sqlServerConn.Database;
                sqlServerConn.Close();
            }

            if (this.Parameters.Count > 0)
            {
                sb.Append($"EXEC {dbName}.dbo.{spName} ");
                var first = true;

                foreach (var p in Parameters)
                {
                    if (first)
                    {
                        first = false;

                        if ((p.DbType == System.Data.DbType.String) || (p.DbType == System.Data.DbType.DateTime))
                            sb.AppendFormat("{0}='{1}'", p.ParameterName, (p.Value is null) ? "NULL" : p.Value);
                        else
                            sb.AppendFormat("{0}={1}", p.ParameterName, (p.Value is null) ? "NULL" : p.Value);
                    }
                    else
                    {
                        if ((p.DbType == System.Data.DbType.String) || (p.DbType == System.Data.DbType.DateTime))
                            sb.AppendFormat(", {0}='{1}'", p.ParameterName, (p.Value is null) ? "NULL" : p.Value);
                        else
                            sb.AppendFormat(", {0}={1}", p.ParameterName, (p.Value is null) ? "NULL" : p.Value);
                    }
                }
            }
            else
            {
                sb.Append($"EXEC {dbName}.dbo.{spName} ");
            }

            this.SQLDetail = sb.ToString();

            return this.SQLDetail;
        }

        public void AddParameter(string parameterName, object parameterValue)
        {
            this.Parameters.Add(new SqlParameter(parameterName, parameterValue));
        }

        public SqlDataReader ExecReader()
        {
            string sqlConnectionString;
            if (SqlTimeOut > 0)
                sqlConnectionString = ConnectionString + ";Connection Timeout=" + SqlTimeOut.ToString();
            else
                sqlConnectionString = ConnectionString;

            if (this.Parameters.Count > 0)
            {
                return SqlHelper.ExecuteReader(sqlConnectionString, CommandType.StoredProcedure, this.storedProcedureName, Parameters.ToArray());
            }
            else
            {
                return SqlHelper.ExecuteReader(sqlConnectionString, CommandType.StoredProcedure, this.storedProcedureName);
            }
        }

        public void ExecNonQuery()
        {
            string sqlConnectionString;
            if (SqlTimeOut > 0)
                sqlConnectionString = ConnectionString + ";Connection Timeout=" + SqlTimeOut.ToString();
            else
                sqlConnectionString = ConnectionString;

            if (Parameters.Count > 0)
                SqlHelper.ExecuteNonQuery(sqlConnectionString, CommandType.StoredProcedure, this.storedProcedureName, Parameters.ToArray());
            else
                SqlHelper.ExecuteNonQuery(sqlConnectionString, CommandType.StoredProcedure, this.storedProcedureName);

        }

        public void Close()
        {
            timeStop = DateTime.Now;
        }
        #endregion
    }
}
