﻿namespace Pacman.Vendor.Polo.API.Entities
{
    public class Callback
    {
        public static BasicEntity InsertLog(Model.Log data)
        {
            var retVal = new BasicEntity(data.Currency);

            retVal.AddParameter("@request", data.Request);
            retVal.AddParameter("@response", data.Response);
            retVal.AddParameter("@method", data.Method);
            _ = retVal.SQLCommandBuilder("spCallbackCallLog");

            retVal.ExecNonQuery();
            retVal.Close();

            return retVal;
        }
    }
}
