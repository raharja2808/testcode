﻿using System.Data.SqlClient;

namespace Pacman.Vendor.Polo.API.Entities
{
    public class FundIn
    {
        public static BasicEntity IBPending(Model.Request data, Output.OutputBase obj)
        {
            var retVal = new BasicEntity(data.Currency);

            retVal.AddParameter("@pg_merchant_id", data.PGMerchantID);
            retVal.AddParameter("@currency", data.Currency);
            retVal.AddParameter("@merchant_transaction_id", data.MerchantTransactionID);
            retVal.AddParameter("@merchant_id", data.MerchantID);
            retVal.AddParameter("@amount", data.Amount);
            retVal.AddParameter("@payment_channel_id", data.MerchantPaymentChannel);
            retVal.AddParameter("@payment_channel_id_vendor", data.PGMerchantPaymentChannel);
            retVal.AddParameter("@bank_code", data.BankCode);
            retVal.AddParameter("@bank_code_vendor", data.BankCodeVendor);
            retVal.AddParameter("@transaction_date", data.DateRequest);
            data.SqlDetail = retVal.SQLCommandBuilder("spPGPoloFundInIBPending");

            using (SqlDataReader reader = retVal.ExecReader())
            {
                while (reader.Read())
                {
                    obj.ResultCode = (reader.IsDBNull(0)) ? 0 : reader.GetInt32(0);
                    obj.ErrorMessage = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                    retVal.ResultCode = obj.ResultCode;
                }

                reader.Close();
            }

            retVal.Close();

            return retVal;
        }

        public static BasicEntity IBPendingStatus(Model.PGStatus data, Output.Notification obj)
        {
            var retVal = new BasicEntity(data.Currency);

            retVal.AddParameter("@merchant_transaction_id", data.MerchantTransactionID);
            retVal.AddParameter("@status", data.Status);
            retVal.AddParameter("@trigger_by", data.TriggerBy);
            retVal.AddParameter("@transaction_note", data.TransactionNote);
            data.SqlDetail = retVal.SQLCommandBuilder("spPGPoloFundInIBPendingStatus");

            using (SqlDataReader reader = retVal.ExecReader())
            {
                while (reader.Read())
                {
                    obj.ResultCode = (reader.IsDBNull(0)) ? 0 : reader.GetInt32(0);
                    obj.ErrorMessage = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                    retVal.ResultCode = obj.ResultCode;
                }

                if (obj.ResultCode == 1)
                {
                    reader.NextResult();
                    while (reader.Read())
                    {
                        obj.Content.MerchantTransactionID = (reader.IsDBNull(0)) ? string.Empty : reader.GetString(0);
                        obj.Content.Status = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                        obj.Content.CallbackResponse = (reader.IsDBNull(2)) ? string.Empty : reader.GetString(2);
                    }
                }
                reader.Close();
            }

            retVal.Close();

            return retVal;
        }
    }
}
