﻿using System.Data.SqlClient;

namespace Pacman.Vendor.Polo.API.Entities
{
    public class Customer
    {
        public static BasicEntity Info(Model.PGBase data, Output.Merchant obj)
        {
            var retVal = new BasicEntity(data.Currency);

            retVal.AddParameter("@merchant_id", data.MerchantID);
            retVal.AddParameter("@currency", data.Currency);
            retVal.AddParameter("@pg_merchant_id", data.PGMerchantID);
            retVal.AddParameter("@merchant_payment_channel", data.MerchantPaymentChannel);
            retVal.AddParameter("@merchant_payment_channel_vendor", data.PGMerchantPaymentChannel);
            retVal.AddParameter("@bank_code", data.BankCode);
            data.SqlDetail = retVal.SQLCommandBuilder("spPGPoloCustomerInfo");

            using (SqlDataReader reader = retVal.ExecReader())
            {
                while (reader.Read())
                {
                    obj.ResultCode = (reader.IsDBNull(0)) ? 0 : reader.GetInt32(0);
                    obj.ErrorMessage = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                    retVal.ResultCode = obj.ResultCode;
                }

                if (retVal.ResultCode == 1)
                {
                    reader.NextResult();
                    while (reader.Read())
                    {
                        obj.Content.PGMerchantID = (reader.IsDBNull(0)) ? string.Empty : reader.GetString(0);
                        obj.Content.PGMerchantPassKey = (reader.IsDBNull(1)) ? string.Empty : reader.GetString(1);
                        obj.Content.MerchantPaymentChannel = (reader.IsDBNull(2)) ? string.Empty : reader.GetString(2);
                        obj.Content.RequestURLFundIn = (reader.IsDBNull(3)) ? string.Empty : reader.GetString(3);
                        obj.Content.ReturnURLFundIn = (reader.IsDBNull(4)) ? string.Empty : reader.GetString(4);
                        obj.Content.MerchantPaymentChannelVendor = (reader.IsDBNull(5)) ? string.Empty : reader.GetString(5);
                        obj.Content.RequestURLFundOut = (reader.IsDBNull(6)) ? string.Empty : reader.GetString(6);
                        obj.Content.BankCode = (reader.IsDBNull(7)) ? string.Empty : reader.GetString(7);
                        obj.Content.BankCodeVendor = (reader.IsDBNull(8)) ? string.Empty : reader.GetString(8);
                    }
                }

                reader.Close();
            }

            retVal.Close();

            return retVal;
        }
    }
}
