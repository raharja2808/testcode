﻿namespace Pacman.Vendor.Polo.API.Handler
{
    public class APIHandler
    {
        #region -= Fields =-
        private readonly IHttpClientFactory ClientFactory;
        public static IConfiguration appConfig;
        #endregion

        #region -= Constructor =-
        public APIHandler(RequestDelegate requestDelegate, IHttpClientFactory httpClientFactory, IConfiguration configuration)
        {
            this.ClientFactory = httpClientFactory;
            appConfig = configuration;
        }
        #endregion

        #region -= Methods =-
        public async Task Invoke(HttpContext context)
        {
            string response = await GenerateResponse(context);

            context.Response.ContentType = "application/json";

            await context.Response.WriteAsync(response);
        }

        private async Task<string> GenerateResponse(HttpContext context)
        {
            string retVal;
            string path = context.Request.Path;

            switch (path.ToLower())
            {
                case "/polo/fund_in.api": { retVal = await new Services.FundIn(context, ClientFactory).GetResponse(); break; }
                //case "/polo/fund_in_query.api": { retVal = await new Services.FundInQuery(context, ClientFactory).GetResponse(); break; }

                //case "/polo/fund_out.api": { retVal = await new Services.FundOut(context, ClientFactory).GetResponse(); break; }
                //case "/polo/fund_out_query.api": { retVal = await new Services.FundOutQuery(context, ClientFactory).GetResponse(); break; }

                //// Vendor Callback
                case "/polo/fund_in_ib_status_success.api": { retVal = await new Services.FundInIBStatusSuccess(context).GetResponse(); break; }
                //case "/polo/fund_in_ib_status_failed.api": { retVal = await new Services.FundInIBStatusFailed(context).GetResponse(); break; }
                //case "/polo/fund_out_ib_status_success.api": { retVal = await new Services.FundOutIBStatusSuccess(context).GetResponse(); break; }
                //case "/polo/fund_out_ib_status_failed.api": { retVal = await new Services.FundOutIBStatusFailed(context.GetResponse(); break; }


                default: { retVal = DefaultResponse(); break; }
            }

            return retVal;
        }

        private static string DefaultResponse()
        {
            var response = new { ResultCode = 69999, ErrorMessage = "Path Not Found" };

            return Helper.JSONHelper.Serialize(response);
        }
        #endregion
    }
}
