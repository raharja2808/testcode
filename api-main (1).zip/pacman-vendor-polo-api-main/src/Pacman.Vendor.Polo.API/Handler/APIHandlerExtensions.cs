﻿namespace Pacman.Vendor.Polo.API
{
    public static class APIHandlerExtensions
    {
        public static IApplicationBuilder UseAPIHandler(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<Handler.APIHandler>();
        }
    }
}
