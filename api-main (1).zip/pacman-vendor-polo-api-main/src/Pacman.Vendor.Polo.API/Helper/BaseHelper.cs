﻿using System.Text;

namespace Pacman.Vendor.Polo.API.Helper
{
    public class BaseHelper
    {
        #region -= Fields =-
        private Exception exception;
        private StringBuilder sb = new();
        private Int32 stepNumber = 0;
        private StringBuilder sbSql = new();
        #endregion

        #region -= Properties =-
        public Int32 ResultCode { get; set; }
        public string ResultMessage { get; set; }
        public string ErrorMessage { get; set; }
        public string JSONString { get; set; }
        public bool IsThrowException
        {
            get
            {
                if (exception == null)
                    return false;
                else
                    return true;
            }
        }
        public Exception Exception { get { return exception; } set { exception = value; this.ResultCode = 69999; this.ErrorMessage = exception.Message; } }
        public bool IsError { get; set; }
        public string SQLDetail { get { return sbSql.ToString(); } }
        public string ProcedureFlow { get { return sb.ToString(); } }
        public string StampUser { get; set; }
        public bool SQLException { get; set; }
        public double SQLElapsed { get; set; }
        public string ProviderCode { get; set; }
        public string ShortMessage { get; set; }
        public string Currency { get; set; }
        #endregion

        #region -= Constructor =-
        public BaseHelper()
        {
            this.ResultCode = 0;
            this.ErrorMessage = "Default Error Message";
            this.IsError = true;
            this.SQLException = false;
            this.JSONString = JSONHelper.Serialize(new Output.OutputBase());
        }
        #endregion

        #region -= Methods =-
        public void SerializeObject<T>(T data)
        {
            //JSONString = JsonConvert.SerializeObject(data, new JsonSerializerSettings() { NullValueHandling = NullValueHandling.Ignore });
            JSONString = JSONHelper.Serialize(data);
        }

        public void Step(string label, int resultCode)
        {

            var resultValue = (resultCode == 1) ? "Success[1]" : "Error[" + ResultCode + "]";
            sb.AppendLine(string.Format("{0}) {1} : [{2}] result = {3}", ++stepNumber, "Vertu Integration", label, resultValue));
        }

        public void SQLInfo(string sql)
        {
            sbSql.AppendLine(sql);
        }
        #endregion
    }
}
