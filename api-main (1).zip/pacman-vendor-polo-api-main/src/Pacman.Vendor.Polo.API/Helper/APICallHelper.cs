﻿using Pacman.Vendor.Polo.API.Entities;
using System.Globalization;
using System.Text;

namespace Pacman.Vendor.Polo.API.Helper
{
    public class APICallHelper
    {
        #region -= Properties =-
        public IHttpClientFactory HttpClientFactory { get; set; }
        #endregion

        #region -= Contructor =-
        public APICallHelper(IHttpClientFactory httpClientFactory)
        {
            this.HttpClientFactory = httpClientFactory;
        }
        #endregion

        #region -= Private Methods =-
        private HttpClient GetClient(string apiClient)
        {
            return this.HttpClientFactory.CreateClient(apiClient);
        }

        private async Task<T> HttpClient<T, U>(Model.APICall log, string apiClient, string url, U data)
        {
            T retVal = default;
            var client = GetClient(apiClient);
            var content = new StringContent(JSONHelper.Serialize(data), Encoding.UTF8, "application/json");
            log.Request = $"{client.BaseAddress}{url} {JSONHelper.Serialize(data)}";

            try
            {
                var result = await client.PostAsync(url, content);

                result.EnsureSuccessStatusCode();

                if (result.IsSuccessStatusCode)
                {
                    var received = await result.Content.ReadAsStringAsync();

                    retVal = JSONHelper.Deserialize<T>(received);
                    log.Response = received;
                    var obj = new Output.OutputBase();
                    Entities.RequestResponseLog.Insert(log, obj);
                }
                else
                {
                    log.APIException = new Exception(result.ReasonPhrase);
                    log.Response = result.ReasonPhrase;
                    var obj = new Output.OutputBase();
                    Entities.RequestResponseLog.Insert(log, obj);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                log.APIException = ex;
                log.Response = ex.Message;
                var obj = new Output.OutputBase();
                Entities.RequestResponseLog.Insert(log, obj);
            }
            finally
            {
                content.Dispose();
            }

            return retVal;
        }
        #endregion

        #region -= AdminSM =-
        #endregion
    }
}
