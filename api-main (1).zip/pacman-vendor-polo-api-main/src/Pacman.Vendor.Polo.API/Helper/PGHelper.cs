﻿using Pacman.Vendor.Polo.API.Entities;

namespace Pacman.Vendor.Polo.API.Helper
{
    public class PGHelper
    {
        #region -= Fund In =-
        public static async Task<BaseHelper> FundIn(APICallHelper api, Model.Request data)
        {
            var retVal = new BaseHelper();
            var objJSON = new Output.Merchant();
            var objJSONPage = new Output.FundIn();
            var objJSONPending = new Output.OutputBase();

            retVal.ShortMessage = $"Fund In: <{data.MerchantID}> <{data.Currency}>";

            try
            {
                if (data.Amount <= 0)
                {
                    objJSONPage.ResultCode = 40001;
                    objJSONPage.ErrorMessage = "Invalid amount";

                    retVal.ShortMessage = $"Fund In: <{data.MerchantID}> <{data.Currency}> [{objJSONPage.ErrorMessage}]";
                }
                else
                {
                    if (string.IsNullOrEmpty(data.Currency))
                    {
                        objJSONPage.ResultCode = 40002;
                        objJSONPage.ErrorMessage = "Currency Not Found";
                    }
                    else
                    {
                        var entity = await Task.Run(() => Customer.Info(data, objJSON));
                        retVal.SQLElapsed = entity.SQLElapsed;
                        retVal.SQLInfo($"sp : {entity.SQLDetail}, elapsed : {entity.SQLElapsed}");
                        retVal.Step("Customer Info", entity.ResultCode);

                        var isValidRequest = false;

                        if (objJSON.ResultCode == 1)
                        {

                            if (objJSON.Content.MerchantPaymentChannel.Equals("QR", StringComparison.InvariantCultureIgnoreCase))
                                isValidRequest = true;
                            else if (objJSON.Content.MerchantPaymentChannel.Equals("IB", StringComparison.InvariantCultureIgnoreCase))
                                isValidRequest = true;
                            else if (objJSON.Content.MerchantPaymentChannel.Equals("VA", StringComparison.InvariantCultureIgnoreCase))
                                isValidRequest = true;
                            else
                                isValidRequest = false;

                            if (isValidRequest)
                            {
                                data.BankCodeVendor = objJSON.Content.BankCodeVendor;

                                var queryString = Util.URLEncode($"merchanttransactionid={data.MerchantTransactionID}&currency={data.Currency}&pg_id=polo&signature={Util.CreateSignatureConfirmation(data.Currency, $"{data.MerchantTransactionID}{data.Currency}")}");
                                objJSON.Content.ReturnURLFundIn = $"{objJSON.Content.ReturnURLFundIn}?{queryString}";

                                if (objJSON.Content.MerchantPaymentChannel.Equals("QR", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    // TO DO:
                                }
                                else if (objJSON.Content.MerchantPaymentChannel.Equals("IB", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    var entityPending = await Task.Run(() => Entities.FundIn.IBPending(data, objJSONPending));
                                    retVal.SQLElapsed = entityPending.SQLElapsed;
                                    retVal.SQLInfo($"sp : {entityPending.SQLDetail}, elapsed : {entityPending.SQLElapsed}");
                                    retVal.Step("Fund In IB Pending", entityPending.ResultCode);

                                    if (objJSONPending.ResultCode == 1)
                                    {
                                        retVal.IsError = false;
                                        retVal.ResultCode = 1;
                                        retVal.ErrorMessage = string.Empty;

                                        objJSONPage.ResultCode = 1;
                                        objJSONPage.ErrorMessage = string.Empty;

                                        objJSONPage.Content.MerchantTransactionID = data.MerchantTransactionID;
                                        objJSONPage.Content.Amount = data.Amount;
                                        objJSONPage.Content.Currency = data.Currency;
                                        objJSONPage.Content.BankCode = data.BankCode;
                                    }
                                    else
                                    {

                                    }
                                }
                                else if (objJSON.Content.MerchantPaymentChannel.Equals("VA", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    // TO DO:
                                }
                                else
                                {
                                    objJSONPage.ResultCode = 40005;
                                    objJSONPage.ErrorMessage = "Payment Channel Not Available";
                                }
                            }
                            else
                            {
                                objJSONPage.ResultCode = 40006;
                                objJSONPage.ErrorMessage = $"({objJSONPending.ResultCode}) {objJSONPending.ErrorMessage}";
                            }
                        }
                        else
                        {
                            objJSONPage.ResultCode = 40003;
                            objJSONPage.ErrorMessage = "Merchant Not Ready (PoloPay Setting)";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                retVal.Exception = ex;

                if (ex is System.Data.SqlClient.SqlException sqlEx)
                {
                    retVal.SQLInfo($"sp:{sqlEx.Procedure}, line:{sqlEx.LineNumber}, detail:{data.SqlDetail}");
                    retVal.SQLException = true;

                    objJSONPage.ResultCode = 69998;
                    objJSONPage.ErrorMessage = "SQL Exception";
                }
                else
                {
                    objJSONPage.ResultCode = 69999;
                    objJSONPage.ErrorMessage = "Unknown Error";
                }
            }
            finally
            {
                retVal.SerializeObject<Output.OutputBase>(objJSONPage);
            }

            return retVal;
        }

        public static async Task<BaseHelper> FundInQuery(APICallHelper api, Model.Request data)
        {
            var retVal = new BaseHelper();
            var objJSON = new Output.Merchant();
            var objJSONPage = new Output.FundQuery();

            retVal.ShortMessage = $"Fund In Query: <{data.PGMerchantID}> <{data.MerchantTransactionID}> <{data.Currency}>";

            try
            {
                if (string.IsNullOrEmpty(data.Currency))
                {
                    objJSONPage.ResultCode = 40002;
                    objJSONPage.ErrorMessage = "Currency Not Found";
                }
                else if (string.IsNullOrEmpty(data.PGMerchantID))
                {
                    objJSONPage.ResultCode = 40007;
                    objJSONPage.ErrorMessage = "PG Merchant ID Not Found";
                }
                else
                {
                    var entity = await Task.Run(() => PG.Info(data, objJSON));
                    retVal.SQLElapsed = entity.SQLElapsed;
                    retVal.SQLInfo($"sp : {entity.SQLDetail}, elapsed : {entity.SQLElapsed}");
                    retVal.Step("Customer Info", entity.ResultCode);

                    if (objJSON.ResultCode == 1)
                    {
                        // TO DO:
                    }
                    else
                    {
                        objJSONPage.ResultCode = 40003;
                        objJSONPage.ErrorMessage = "Merchant Not Ready (PoloPay Setting)";
                    }
                }
            }
            catch (Exception ex)
            {
                retVal.Exception = ex;

                if (ex is System.Data.SqlClient.SqlException sqlEx)
                {
                    retVal.SQLInfo($"sp:{sqlEx.Procedure}, line:{sqlEx.LineNumber}, detail:{data.SqlDetail}");
                    retVal.SQLException = true;

                    objJSONPage.ResultCode = 69998;
                    objJSONPage.ErrorMessage = "SQL Exception";
                }
                else
                {
                    objJSONPage.ResultCode = 69999;
                    objJSONPage.ErrorMessage = "Unknown Error";
                }
            }
            finally
            {
                retVal.SerializeObject<Output.OutputBase>(objJSONPage);
            }

            return retVal;
        }

        // Callback API called by Vendor
        public static async Task<BaseHelper> FundInIBStatus(Model.FundInStatus data)
        {
            var retVal = new BaseHelper();
            var objJSON = new Output.Notification();
            var objJSONPage = new Output.OutputBase();

            retVal.ShortMessage = $"Fund In Status: <{data.MerchantTransactionID}> <{data.Status}>";

            try
            {
                if (string.IsNullOrEmpty(data.Currency) | string.IsNullOrEmpty(data.Status)
                    | string.IsNullOrEmpty(data.MerchantTransactionID) 
                    )
                {
                    objJSONPage.ResultCode = 40009;
                    objJSONPage.ErrorMessage = "Invalid Parameters";

                    return retVal;
                }
                else
                {
                    var dataPending = new Model.PGStatus
                    {
                        MerchantTransactionID = data.MerchantTransactionID,
                        Status = data.Status,
                        TriggerBy = "VENDOR POLO",
                        TransactionNote = data.Reason
                    };

                    var entity = await Task.Run(() => Entities.FundIn.IBPendingStatus(dataPending, objJSON));
                    retVal.SQLElapsed = entity.SQLElapsed;
                    retVal.SQLInfo($"sp : {entity.SQLDetail}, elapsed : {entity.SQLElapsed}");
                    retVal.Step("Customer Info", entity.ResultCode);

                    if (entity.ResultCode == 1)
                    {
                        retVal.IsError = false;

                        objJSONPage.ResultCode = 1;
                        objJSONPage.ErrorMessage = string.Empty;
                    }
                    else
                    {
                        objJSONPage.ResultCode = objJSON.ResultCode;
                        objJSONPage.ErrorMessage = objJSON.ErrorMessage;
                    }
                }
            }
            catch (Exception ex)
            {
                retVal.Exception = ex;

                if (ex is System.Data.SqlClient.SqlException sqlEx)
                {
                    retVal.SQLInfo($"sp:{sqlEx.Procedure}, line:{sqlEx.LineNumber}, detail:");
                    retVal.SQLException = true;

                    objJSONPage.ResultCode = 69998;
                    objJSONPage.ErrorMessage = "SQL Exception";
                }
                else
                {
                    objJSONPage.ResultCode = 69999;
                    objJSONPage.ErrorMessage = "Unknown Error";
                }
            }
            finally
            {
                retVal.SerializeObject<Output.OutputBase>(objJSONPage);
            }

            return retVal;
        }

        #endregion

        #region -= Fund Out =-
        public static async Task<BaseHelper> FundOut(APICallHelper api, Model.Request data)
        {
            var retVal = new BaseHelper();
            var objJSON = new Output.Merchant();
            var objJSONPage = new Output.FundOut();
            var objJSONPending = new Output.OutputBase();

            retVal.ShortMessage = $"Fund Out: <{data.MerchantID}> <{data.Currency}>";

            try
            {
                if (data.Amount <= 0)
                {
                    objJSONPage.ResultCode = 40001;
                    objJSONPage.ErrorMessage = "Invalid amount";

                    retVal.ShortMessage = $"Fund Out: <{data.MerchantID}> <{data.Currency}> [{objJSONPage.ErrorMessage}]";
                }
                else
                {
                    if (string.IsNullOrEmpty(data.Currency))
                    {
                        objJSONPage.ResultCode = 40002;
                        objJSONPage.ErrorMessage = "Currency Not Found";
                    }
                    else
                    {
                        var entity = await Task.Run(() => Customer.Info(data, objJSON));
                        retVal.SQLElapsed = entity.SQLElapsed;
                        retVal.SQLInfo($"sp : {entity.SQLDetail}, elapsed : {entity.SQLElapsed}");
                        retVal.Step("Customer Info", entity.ResultCode);

                        if (objJSON.ResultCode == 1)
                        {
                            data.BankCodeVendor = objJSON.Content.BankCodeVendor;

                            var entityPending = await Task.Run(() => Entities.FundOut.Pending(data, objJSONPending));
                            retVal.SQLElapsed = entityPending.SQLElapsed;
                            retVal.SQLInfo($"sp : {entityPending.SQLDetail}, elapsed : {entityPending.SQLElapsed}");
                            retVal.Step("Fund Out Pending", entityPending.ResultCode);

                            if (objJSONPending.ResultCode == 1)
                            {
                                if (objJSON.Content.MerchantPaymentChannel.Equals("IB", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    // TO DO:
                                }
                                else
                                {
                                    objJSONPage.ResultCode = 40005;
                                    objJSONPage.ErrorMessage = "Payment Channel Not Available";
                                }
                            }
                            else
                            {
                                objJSONPage.ResultCode = 40006;
                                objJSONPage.ErrorMessage = $"({objJSONPending.ResultCode}) {objJSONPending.ErrorMessage}";
                            }
                        }
                        else
                        {
                            objJSONPage.ResultCode = 40003;
                            objJSONPage.ErrorMessage = "Merchant Not Ready (PoloPay Setting)";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                retVal.Exception = ex;

                if (ex is System.Data.SqlClient.SqlException sqlEx)
                {
                    retVal.SQLInfo($"sp:{sqlEx.Procedure}, line:{sqlEx.LineNumber}, detail:{data.SqlDetail}");
                    retVal.SQLException = true;

                    objJSONPage.ResultCode = 69998;
                    objJSONPage.ErrorMessage = "SQL Exception";
                }
                else
                {
                    objJSONPage.ResultCode = 69999;
                    objJSONPage.ErrorMessage = "Unknown Error";
                }
            }
            finally
            {
                retVal.SerializeObject<Output.FundOut>(objJSONPage);
            }

            return retVal;
        }

        public static async Task<BaseHelper> FundOutQuery(APICallHelper api, Model.Request data)
        {
            var retVal = new BaseHelper();
            var objJSON = new Output.Merchant();
            var objJSONPage = new Output.FundQuery();

            retVal.ShortMessage = $"Fund Out Query: <{data.PGMerchantID}> <{data.MerchantTransactionID}> <{data.Currency}>";

            try
            {
                if (string.IsNullOrEmpty(data.Currency))
                {
                    objJSONPage.ResultCode = 40002;
                    objJSONPage.ErrorMessage = "Currency Not Found";
                }
                else if (string.IsNullOrEmpty(data.PGMerchantID))
                {
                    objJSONPage.ResultCode = 40007;
                    objJSONPage.ErrorMessage = "PG Merchant ID Not Found";
                }
                else
                {
                    var entity = await Task.Run(() => PG.Info(data, objJSON));
                    retVal.SQLElapsed = entity.SQLElapsed;
                    retVal.SQLInfo($"sp : {entity.SQLDetail}, elapsed : {entity.SQLElapsed}");
                    retVal.Step("Customer Info", entity.ResultCode);

                    if (objJSON.ResultCode == 1)
                    {
                        // TO DO:
                    }
                    else
                    {
                        objJSONPage.ResultCode = 40003;
                        objJSONPage.ErrorMessage = "Merchant Not Ready (PoloPay Setting)";
                    }
                }
            }
            catch (Exception ex)
            {
                retVal.Exception = ex;

                if (ex is System.Data.SqlClient.SqlException sqlEx)
                {
                    retVal.SQLInfo($"sp:{sqlEx.Procedure}, line:{sqlEx.LineNumber}, detail:{data.SqlDetail}");
                    retVal.SQLException = true;

                    objJSONPage.ResultCode = 69998;
                    objJSONPage.ErrorMessage = "SQL Exception";
                }
                else
                {
                    objJSONPage.ResultCode = 69999;
                    objJSONPage.ErrorMessage = "Unknown Error";
                }
            }
            finally
            {
                retVal.SerializeObject<Output.OutputBase>(objJSONPage);
            }

            return retVal;
        }

        // Callback API called by Vendor
        public static async Task<BaseHelper> FundOutStatus(Model.FundOutStatus data)
        {
            var retVal = new BaseHelper();
            var objJSON = new Output.Merchant();
            var objJSONPage = new Output.FundIn();

            retVal.ShortMessage = $"Fund Out Status: <{data.PGTransactionID}> <{data.PGMerchantID}>";

            try
            {
                // TO DO:
            }
            catch (Exception ex)
            {
                retVal.Exception = ex;

                if (ex is System.Data.SqlClient.SqlException sqlEx)
                {
                    retVal.SQLInfo($"sp:{sqlEx.Procedure}, line:{sqlEx.LineNumber}, detail:");
                    retVal.SQLException = true;

                    objJSONPage.ResultCode = 69998;
                    objJSONPage.ErrorMessage = "SQL Exception";
                }
                else
                {
                    objJSONPage.ResultCode = 69999;
                    objJSONPage.ErrorMessage = "Unknown Error";
                }
            }
            finally
            {
                retVal.SerializeObject<Output.OutputBase>(objJSONPage);
            }

            return retVal;
        }

        #endregion
    }
}
