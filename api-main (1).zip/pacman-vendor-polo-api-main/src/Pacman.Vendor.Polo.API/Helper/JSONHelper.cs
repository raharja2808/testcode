﻿using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Pacman.Vendor.Polo.API.Helper
{
    public class JSONHelper
    {
        private static JsonSerializerOptions jsonSettings;

        private static JsonSerializerOptions JSONSettings()
        {
            if (jsonSettings == null)
            {
                jsonSettings = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                jsonSettings.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
                jsonSettings.Converters.Add(new DateTimeConverterUsingDateTimeParse());
                jsonSettings.Converters.Add(new StringToInt32Converter());
                jsonSettings.Converters.Add(new StringToInt64Converter());
                jsonSettings.Converters.Add(new StringToDecimalConverter());
            }

            return jsonSettings;
        }

        public static string Serialize(object obj)
        {
            var jsonBytes = JsonSerializer.SerializeToUtf8Bytes(obj, typeof(object), JSONSettings());
            return UTF8Encoding.UTF8.GetString(jsonBytes);
        }

        public static object Deserialize(string jsonString)
        {
            return JsonSerializer.Deserialize(new ReadOnlySpan<byte>(UTF8Encoding.UTF8.GetBytes(jsonString)), typeof(object), JSONSettings());
        }

        public static T Deserialize<T>(string jsonString)
        {
            return JsonSerializer.Deserialize<T>(new ReadOnlySpan<byte>(UTF8Encoding.UTF8.GetBytes(jsonString)), JSONSettings());
        }
    }

    internal class DateTimeConverterUsingDateTimeParse : JsonConverter<DateTime>
    {
        public override bool CanConvert(Type typeToConvert)
        {
            switch (Type.GetTypeCode(typeToConvert))
            {
                case TypeCode.DateTime:
                    return true;
                default:
                    return false;
            }
        }

        public override DateTime Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.TokenType == JsonTokenType.String)
                return DateTime.Parse(reader.GetString());

            return reader.GetDateTime();
        }

        public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options)
        {
            writer.WriteStringValue($"{value:yyyy/MM/ddTHH}:{value:mm}:{value:ss.fff}");
        }
    }

    internal class StringToInt64Converter : JsonConverter<Int64>
    {
        public override bool CanConvert(Type typeToConvert)
        {
            switch (Type.GetTypeCode(typeToConvert))
            {
                case TypeCode.Int64:
                case TypeCode.UInt64:
                    return true;
                default:
                    return false;
            }
        }

        public override Int64 Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.TokenType == JsonTokenType.String)
                return Int64.Parse(reader.GetString());

            return reader.GetInt64();
        }

        public override void Write(Utf8JsonWriter writer, Int64 value, JsonSerializerOptions options)
        {
            writer.WriteNumberValue(value);
        }
    }

    internal class StringToDecimalConverter : JsonConverter<decimal>
    {
        public override bool CanConvert(Type typeToConvert)
        {
            switch (Type.GetTypeCode(typeToConvert))
            {
                case TypeCode.Decimal:
                    return true;
                default:
                    return false;
            }
        }

        public override decimal Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.TokenType == JsonTokenType.String)
                return decimal.Parse(reader.GetString());

            return reader.GetDecimal();
        }

        public override void Write(Utf8JsonWriter writer, decimal value, JsonSerializerOptions options)
        {
            writer.WriteNumberValue(value);
        }
    }

    internal class StringToInt32Converter : JsonConverter<Int32>
    {
        public override bool CanConvert(Type typeToConvert)
        {
            switch (Type.GetTypeCode(typeToConvert))
            {
                case TypeCode.Int32:
                case TypeCode.UInt32:
                    return true;
                default:
                    return false;
            }
        }

        public override Int32 Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.TokenType == JsonTokenType.String)
                return Int32.Parse(reader.GetString());

            return reader.GetInt32();
        }

        public override void Write(Utf8JsonWriter writer, Int32 value, JsonSerializerOptions options)
        {
            writer.WriteNumberValue(value);
        }
    }
}
