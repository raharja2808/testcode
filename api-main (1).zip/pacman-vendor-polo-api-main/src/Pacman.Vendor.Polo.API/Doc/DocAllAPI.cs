﻿using System.Text;

namespace Pacman.Vendor.Polo.API.Doc
{
    public class DocAllAPI
    {
        public static string Write()
        {
            StringBuilder sb = new();

            sb.AppendLine("===========================================================================");
            sb.AppendLine("Viet2Pay API");
            sb.AppendLine("===========================================================================");
            sb.AppendLine();
            sb.AppendLine("===========================================================================");
            sb.AppendLine("GENERAL");
            sb.AppendLine("===========================================================================");
            sb.AppendLine(General());
            sb.AppendLine();

            return sb.ToString();
        }


        public static string General()
        {
            StringBuilder sb = new();

            var number = 0;

            sb.AppendLine(++number + ") /balance.api");
            sb.AppendLine("example-request :");
            //var balance = new Model.PGBase { PGMerchantID = "01", DateRequest = Convert.ToDateTime("2022-04-07 00:00") };
            //sb.AppendLine(Helper.JSONHelper.Serialize(balance));
            sb.AppendLine();


            return sb.ToString();
        }
    }
}
