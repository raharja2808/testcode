﻿namespace Pacman.Vendor.Polo.API.Model
{
    public class Log
    {
        public string Request { get; set; }
        public string Response { get; set; }
        public string Method { get; set; }
        public string Currency { get; set; }
    }
}
