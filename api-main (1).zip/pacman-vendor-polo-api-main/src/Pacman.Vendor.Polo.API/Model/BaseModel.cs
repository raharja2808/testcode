﻿namespace Pacman.Vendor.Polo.API.Model
{
    public class BaseModel
    {
        public string TrackingCode { get; set; }
        public string StampUser { get; set; }
        public string SqlDetail { get; set; }
    }
}
