﻿namespace Pacman.Vendor.Polo.API.Model
{
    public class PGStatus : PGBase
    {
        public string MerchantTransactionID { get; set; }
        public string PGTransactionID { get; set; }
        public string Status { get; set; }
        public string ValidationKey { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorDescription { get; set; }
        public string TriggerBy { get; set; }
        public string TransactionNote { get; set; }
    }
}
