﻿namespace Pacman.Vendor.Polo.API.Model
{
    public class Testing : BaseModel
    {
        public string InputString { get; set; }
    }
}
