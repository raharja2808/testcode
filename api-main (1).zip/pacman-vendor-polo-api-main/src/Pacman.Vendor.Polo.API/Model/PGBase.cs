﻿namespace Pacman.Vendor.Polo.API.Model
{
    public class PGBase : BaseModel
    {
        public string MerchantID { get; set; }
        public string PGMerchantID { get; set; }
        public string Currency { get; set; }
        public string MerchantPaymentChannel { get; set; }
        public string PGMerchantPaymentChannel { get; set; }
        public string BankCode { get; set; }
    }
}
