﻿namespace Pacman.Vendor.Polo.API.Model
{
    public class FundOutStatus
    {
        public string PGTransactionID { get; set; }
        public string PGMerchantID { get; set; }
        public string Currency { get; set; }
        public decimal Amount { get; set; }
        public string AccountName { get; set; }
        public string AccountNo { get; set; }
        public string BankCode { get; set; }
        public string Status { get; set; }
        public string Reason { get; set; }
    }
}
