﻿namespace Pacman.Vendor.Polo.API.Model
{
    public class APICall : BaseModel
    {
        public string Request { get; set; }
        public string Response { get; set; }
        public Exception APIException { get; set; }
        public string Currency { get; set; }
    }
}
