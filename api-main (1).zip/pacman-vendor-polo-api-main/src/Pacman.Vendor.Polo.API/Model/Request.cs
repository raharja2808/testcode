﻿namespace Pacman.Vendor.Polo.API.Model
{
    public class Request : PGBase
    {
        public string MerchantTransactionID { get; set; }
        public decimal Amount { get; set; }
        public string IPAddress { get; set; }
        public DateTime DateRequest { get; set; }
        public string BankCodeVendor { get; set; }
        public string PGTransactionID { get; set; }
        public string BankAccountNo { get; set; }
        public string BankAccountName { get; set; }
        public string BankBranch { get; set; }
        public string BankCity { get; set; }
        public string BankProvince { get; set; }
        public decimal Fee { get; set; }
    }
}
