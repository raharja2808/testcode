--USE [PacmanPoloDB]
--GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[spPGPoloFundInIBPendingStatus]
(
	@merchant_transaction_id varchar(50),
	@status varchar(20),
	@trigger_by varchar(20),
	@transaction_note varchar(500)
) 
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @result_code int, @result_message varchar(8000)
		, @pg_merchant_id varchar(100), @response varchar(1000)
		, @pg_transaction_id varchar(50)
	-----------------------------------------------------------------------------------------------------------
	SELECT @response = ''
	-----------------------------------------------------------------------------------------------------------
	IF EXISTS(SELECT merchant_transaction_id FROM dbo.fundin_history WITH(NOLOCK) WHERE merchant_transaction_id = @merchant_transaction_id)
	BEGIN
		IF @status IN ('SUCCESS')
		BEGIN
			SELECT @response = pg_transaction_id
			FROM dbo.fundin_history WITH(NOLOCK) WHERE merchant_transaction_id = @merchant_transaction_id

			IF (SELECT fundin_status FROM dbo.fundin_history WITH(NOLOCK) WHERE merchant_transaction_id = @merchant_transaction_id) IN ('FAILED','PENDING')
			BEGIN
				SELECT @pg_merchant_id = pg_merchant_id
				FROM dbo.fundin_history WITH(NOLOCK)
				WHERE merchant_transaction_id = @merchant_transaction_id

				BEGIN TRY
					BEGIN TRANSACTION

					INSERT INTO dbo.fundin_history_log(merchant_id, currency
						, merchant_transaction_id, pg_merchant_id, amount, date_fundin_request
						, date_fundin_notify, pg_transaction_id, fundin_status
						, payment_channel_id, payment_channel_id_vendor
						, bank_code, bank_code_vendor, trigger_by, transaction_note
					)
					SELECT merchant_id, currency
						, merchant_transaction_id, pg_merchant_id, amount, date_fundin_request
						, date_fundin_notify, pg_transaction_id, fundin_status
						, payment_channel_id, payment_channel_id_vendor
						, bank_code, bank_code_vendor, trigger_by, transaction_note
					FROM dbo.fundin_history WITH(NOLOCK)
					WHERE merchant_transaction_id = @merchant_transaction_id

					UPDATE dbo.fundin_history
					SET fundin_status = @status
						, date_fundin_notify = dbo.fnGetDateGMT7()
						, trigger_by = @trigger_by
						, transaction_note = @transaction_note
					WHERE merchant_transaction_id = @merchant_transaction_id

					INSERT INTO dbo.fundin_callback(merchant_transaction_id, transaction_status, pg_merchant_id, trigger_by
						, transaction_note)
					VALUES(UPPER(@merchant_transaction_id), UPPER(@status), @pg_merchant_id, @trigger_by, @transaction_note)

					COMMIT TRANSACTION
				END TRY
				BEGIN CATCH
					ROLLBACK TRANSACTION
				END CATCH
			END
		END

		SELECT @result_code = 1, @result_message = ''
		SELECT @result_code, @result_message
		SELECT @merchant_transaction_id, @status, @response
		RETURN
	END
	-----------------------------------------------------------------------------------------------------------
	IF NOT EXISTS(SELECT merchant_transaction_id FROM dbo.fundin_ib_pending WITH(NOLOCK) WHERE merchant_transaction_id = @merchant_transaction_id)
	BEGIN
		SELECT @result_code = 39999, @result_message = 'Trx ID Not Exist'
		SELECT @result_code, @result_message
		RETURN
	END
	-----------------------------------------------------------------------------------------------------------
	SELECT @pg_merchant_id = pg_merchant_id
	FROM dbo.fundin_ib_pending WITH(NOLOCK)
	WHERE merchant_transaction_id = @merchant_transaction_id
	-----------------------------------------------------------------------------------------------------------
	SELECT @pg_transaction_id = NEWID()
	-----------------------------------------------------------------------------------------------------------
	BEGIN TRY
		BEGIN TRANSACTION

		INSERT INTO dbo.fundin_history(merchant_id, currency
			, merchant_transaction_id, pg_merchant_id, amount, date_fundin_request
			, date_fundin_notify, pg_transaction_id, fundin_status
			, payment_channel_id, payment_channel_id_vendor
			, bank_code, bank_code_vendor, trigger_by, transaction_note
		)
		SELECT merchant_id, currency
			, merchant_transaction_id, pg_merchant_id, amount, date_fundin_request
			, dbo.fnGetDateGMT7(), @pg_transaction_id, @status
			, payment_channel_id, payment_channel_id_vendor
			, bank_code, bank_code_vendor, @trigger_by, @transaction_note
		FROM dbo.fundin_ib_pending WITH(NOLOCK)
		WHERE merchant_transaction_id = @merchant_transaction_id

		INSERT INTO dbo.fundin_callback(merchant_transaction_id, transaction_status, pg_merchant_id, trigger_by, transaction_note)
		VALUES(UPPER(@merchant_transaction_id), UPPER(@status), @pg_merchant_id, @trigger_by, @transaction_note)

		DELETE FROM dbo.fundin_ib_pending WHERE merchant_transaction_id = @merchant_transaction_id

		COMMIT TRANSACTION

		SELECT @response = @pg_transaction_id 
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION

		SELECT @result_code = 39999, @result_message = ERROR_MESSAGE()
		SELECT @result_code, @result_message
		RETURN
	END CATCH
	-----------------------------------------------------------------------------------------------------------
	SELECT @result_code = 1, @result_message = ''

	SELECT @result_code, @result_message
	SELECT @merchant_transaction_id, @status, @response
	RETURN 
END
GO
