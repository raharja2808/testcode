--USE [PacmanPoloDB_THB]
--GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[spPGPoloInfo]
(
	@pg_merchant_id varchar(100),
	@currency varchar(3)
) 
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @result_code int, @result_message varchar(8000)
		, @pg_merchant_passkey varchar(100), @request_url_fund_in varchar(2000)
		, @request_url_fund_out varchar(2000)
	-----------------------------------------------------------------------------------------------------------
	SELECT @pg_merchant_passkey = pg_merchant_passkey
	FROM dbo.master_pg WITH(NOLOCK)
	WHERE pg_merchant_id = @pg_merchant_id AND currency = @currency
	-----------------------------------------------------------------------------------------------------------
	SELECT @result_code = 1, @result_message = ''

	SELECT @result_code, @result_message
	SELECT @pg_merchant_id, @pg_merchant_passkey
	RETURN 
END
GO
