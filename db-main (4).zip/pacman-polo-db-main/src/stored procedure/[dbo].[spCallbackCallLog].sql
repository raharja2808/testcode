--USE [PacmanPoloDB]
--GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[spCallbackCallLog]
(
	@request varchar(8000),
	@response varchar(8000),
	@method varchar(500)
) 
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @result_code int, @result_message varchar(8000)
	-----------------------------------------------------------------------------------------------------------
	INSERT INTO dbo.callback_log(request, response, date_stamp, method)
	VALUES(@request, @response, dbo.fnGetDateGMT7(), @method)
	-----------------------------------------------------------------------------------------------------------

	SELECT @result_code = 1, @result_message = ''

	SELECT @result_code, @result_message
	RETURN 
END
GO
