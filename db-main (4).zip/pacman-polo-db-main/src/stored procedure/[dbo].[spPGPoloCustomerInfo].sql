--USE [PacmanPoloDB]
--GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[spPGPoloCustomerInfo]
(
	@merchant_id varchar(50),
	@currency varchar(3),
	@pg_merchant_id varchar(100),
	@merchant_payment_channel varchar(20),
	@merchant_payment_channel_vendor varchar(20),
	@bank_code varchar(20)
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @result_code int, @result_message varchar(8000)
		, @is_maintenance varchar(1), @pg_merchant_passkey varchar(100)
		, @request_url_fund_in varchar(1000), @return_url_fund_in varchar(1000)
		, @request_url_fund_out varchar(1000), @bank_code_vendor varchar(20)
	-----------------------------------------------------------------------------------------------------------
	SELECT @is_maintenance = 'Y' 
	-----------------------------------------------------------------------------------------------------------
	SELECT @is_maintenance = parameter_value
	FROM dbo.master_parameter WITH(NOLOCK)
	WHERE parameter_key = 'IS_MAINTENANCE'
	-----------------------------------------------------------------------------------------------------------
	IF @is_maintenance = 'Y'
	BEGIN
		SELECT @result_code = 30015, @result_message = 'PG in maintenance mode'
		SELECT @result_code, @result_message
		RETURN
	END
	-----------------------------------------------------------------------------------------------------------
	SELECT @pg_merchant_passkey = pg_merchant_passkey
		, @request_url_fund_in = request_url_fund_in, @return_url_fund_in = return_url_fund_in
		, @request_url_fund_out = request_url_fund_out
	FROM dbo.master_pg WITH(NOLOCK)
	WHERE pg_merchant_id = @pg_merchant_id  AND currency = @currency
		AND pg_merchant_payment_channel = @merchant_payment_channel
		AND pg_merchant_payment_channel_vendor = @merchant_payment_channel_vendor
	-----------------------------------------------------------------------------------------------------------
	IF ((@merchant_id IS NULL) OR (@merchant_id= '') OR (@pg_merchant_passkey IS NULL)) 
	BEGIN
		SELECT @result_code = 30500, @result_message = 'Merchant Setting Not Found'
		SELECT @result_code, @result_message
		RETURN
	END
	-----------------------------------------------------------------------------------------------------------
	SELECT @bank_code_vendor = bank_code_vendor
	FROM dbo.master_bank_mapping WITH(NOLOCK)
	WHERE currency = @currency AND pg_merchant_payment_channel_vendor = @merchant_payment_channel_vendor
		AND bank_code = @bank_code
	-----------------------------------------------------------------------------------------------------------
	IF NOT EXISTS(SELECT merchant_id FROM dbo.master_customer WITH(NOLOCK) WHERE merchant_id = @merchant_id)
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			INSERT INTO dbo.master_customer(merchant_id, currency, date_created, [status])
			VALUES(@merchant_id, @currency, dbo.fnGetDateGMT7(), 'Y')

			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION

			SELECT @result_code = 39999, @result_message = ERROR_MESSAGE()
			SELECT @result_code, @result_message
			RETURN
		END CATCH
	END
	-----------------------------------------------------------------------------------------------------------
	SELECT @result_code = 1, @result_message = ''

	SELECT @result_code, @result_message
	SELECT @pg_merchant_id, @pg_merchant_passkey, @merchant_payment_channel, @request_url_fund_in, @return_url_fund_in
		, @merchant_payment_channel_vendor, @request_url_fund_out, @bank_code, @bank_code_vendor
	RETURN 
END
GO
