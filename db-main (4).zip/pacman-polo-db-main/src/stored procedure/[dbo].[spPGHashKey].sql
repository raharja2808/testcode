--USE [PacmanPoloDB]
--GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[spPGHashKey]
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @key_confirmation varchar(100)
	---------------------------------------------------------------------------------------------
	SELECT @key_confirmation = parameter_value
	FROM dbo.master_parameter WITH(NOLOCK)
	WHERE parameter_key = 'CONFIRMATION_KEY'
	---------------------------------------------------------------------------------------------
	SELECT @key_confirmation
	RETURN
END
GO
