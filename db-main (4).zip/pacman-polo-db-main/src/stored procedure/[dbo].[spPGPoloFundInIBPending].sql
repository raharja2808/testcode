--USE [PacmanPoloDB_THB]
--GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[spPGPoloFundInIBPending]
(
	@merchant_id varchar(50),
	@currency varchar(3),
	@merchant_transaction_id varchar(50),
	@pg_merchant_id varchar(100),
	@amount decimal(18,4),
	@payment_channel_id varchar(20),
	@payment_channel_id_vendor varchar(20),
	@bank_code varchar(10),
	@bank_code_vendor varchar(10),
	@transaction_date datetime
) 
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @result_code int, @result_message varchar(8000)
	-----------------------------------------------------------------------------------------------------------
	IF EXISTS(SELECT merchant_transaction_id FROM dbo.fundin_ib_pending WITH(NOLOCK) WHERE merchant_transaction_id = @merchant_transaction_id)
	BEGIN
		SELECT @result_code = 39999, @result_message = 'Trx ID Exist'
		SELECT @result_code, @result_message
		RETURN
	END
	-----------------------------------------------------------------------------------------------------------
	BEGIN TRY
		BEGIN TRANSACTION

		INSERT INTO dbo.fundin_ib_pending(merchant_id, currency
			, merchant_transaction_id, pg_merchant_id, amount, date_fundin_request
			, payment_channel_id, payment_channel_id_vendor
			, bank_code, bank_code_vendor
		)
		VALUES(@merchant_id, @currency
			, @merchant_transaction_id, @pg_merchant_id, @amount, @transaction_date
			, @payment_channel_id, @payment_channel_id_vendor
			, @bank_code, @bank_code_vendor
		)

		COMMIT TRANSACTION
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION

		SELECT @result_code = 39999, @result_message = ERROR_MESSAGE()
		SELECT @result_code, @result_message
		RETURN
	END CATCH
	-----------------------------------------------------------------------------------------------------------
	SELECT @result_code = 1, @result_message = ''

	SELECT @result_code, @result_message
	RETURN 
END
GO
