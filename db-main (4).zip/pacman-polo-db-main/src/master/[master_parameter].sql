--USE [PacmanPoloDB]
--GO


INSERT INTO dbo.master_parameter(parameter_key, parameter_value, parameter_desc)
VALUES
 ('IS_MAINTENANCE','N','Flag for set maintenance mode')
,('CONFIRMATION_KEY','XSFOERALKSGDDF','HASH KEY SHA512 Confirmation')

