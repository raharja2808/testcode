--USE [PacmanPoloDB]
--GO

/*
DELETE FROM PacmanPoloDB.dbo.master_pg


*/

INSERT INTO [PacmanPoloDB].dbo.master_pg(pg_merchant_id, pg_merchant_passkey, pg_merchant_payment_channel, [pg_merchant_payment_channel_vendor]
	, pg_merchant_note, currency, request_url_fund_in, return_url_fund_in, request_url_fund_out)
VALUES
 ('VTP1','A54QX6S7ZAF','IB','','','IDR','','https://10.20.0.11:3000/payment/confirmation','')
,('VTP2','LP7961JZT9A','QR','','','IDR','','https://10.20.0.11:3000/payment/confirmation','')

