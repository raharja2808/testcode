--USE [PacmanPoloDB]
--GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[master_bank_mapping](
	[currency] [varchar](3) NOT NULL,
	[pg_merchant_payment_channel] [varchar](20) NOT NULL,
	[pg_merchant_payment_channel_vendor] [varchar](20) NOT NULL,
	[bank_code] [varchar](20) NOT NULL,
	[bank_code_vendor] [varchar](20) NOT NULL,
CONSTRAINT [PK_master_bank_mapping] PRIMARY KEY CLUSTERED 
(
	[currency],
	[pg_merchant_payment_channel_vendor],
	[bank_code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [MASTER]
) ON [MASTER]
GO


