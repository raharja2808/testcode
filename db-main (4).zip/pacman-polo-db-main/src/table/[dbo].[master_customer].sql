--USE [PacmanPoloDB]
--GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[master_customer](
	[merchant_id] [varchar](50) NOT NULL,
	[currency] [varchar](3) NOT NULL,
	[date_created] [datetime] NOT NULL,
	[status] [varchar](1) NOT NULL,
	[first_deposit_date] [datetime] NULL,
	[last_deposit_date] [datetime] NULL,
	[first_withdraw_date] [datetime] NULL,
	[last_withdraw_date] [datetime] NULL,
CONSTRAINT [PK_master_customer] PRIMARY KEY CLUSTERED 
(
	[merchant_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [MASTER]
) ON [MASTER]
GO


