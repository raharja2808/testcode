--USE [PacmanPoloDB]
--GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[callback_log](
	[log_id] [bigint] IDENTITY(1,1) NOT NULL,
	[request] [varchar](8000) NOT NULL,
	[response] [varchar](8000) NOT NULL,
	[date_stamp] [datetime] NOT NULL,
	[method] [varchar](500) NULL,
CONSTRAINT [PK_callback_log] PRIMARY KEY CLUSTERED 
(
	[log_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PGLOG]
) ON [PGLOG]
GO


