--USE [PacmanPoloDB]
--GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[fundout_callback](
	[req_id] [bigint] IDENTITY(1,1) NOT NULL,
	[merchant_transaction_id] [varchar](50) NOT NULL,
	[transaction_status] [varchar](50) NOT NULL,
	[pg_merchant_id] [varchar](100) NOT NULL,
	[fee] [decimal](18,4) NOT NULL,
	[trigger_by] [varchar](20) NOT NULL,
	[transaction_note] [varchar](500) NOT NULL,
CONSTRAINT [PK_fundout_callback] PRIMARY KEY CLUSTERED 
(
	[req_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PGFUNDOUT]
) ON [PGFUNDOUT]
GO
