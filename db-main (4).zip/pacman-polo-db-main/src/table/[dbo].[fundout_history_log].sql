--USE [PacmanPoloDB]
--GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[fundout_history_log](
	[log_id] [bigint] IDENTITY(1,1) NOT NULL,
	[merchant_transaction_id] [varchar](50) NOT NULL,
	[merchant_id] [varchar](50) NOT NULL,
	[pg_merchant_id] [varchar](100) NOT NULL,
	[currency] [varchar](3) NOT NULL,
	[amount] [decimal](18,4) NOT NULL,
	[date_fundout_request] [datetime]  NOT NULL,
	[date_fundout_notify] [datetime]  NOT NULL,
	[pg_transaction_id] [varchar](50) NOT NULL,
	[fundout_status] [varchar](20) NOT NULL,
	[fundout_note] [varchar](1000) NOT NULL,
	[payment_channel_id] [varchar](20) NOT NULL,
	[payment_channel_id_vendor] [varchar](20) NOT NULL,
	[bank_code] [varchar](10) NOT NULL,
	[bank_code_vendor] [varchar](10) NOT NULL,
	[account_no] [nvarchar](50) NOT NULL,
	[account_name] [nvarchar](100) NOT NULL,
	[bank_province] [nvarchar](50) NOT NULL,
	[bank_city] [nvarchar](50) NOT NULL,
	[bank_branch] [nvarchar](50) NOT NULL,
	[fee] [decimal](18,4) NOT NULL,
	[trigger_by] [varchar](20) NOT NULL,
	[transaction_note] [varchar](500) NOT NULL,
CONSTRAINT [PK_fundout_history_log] PRIMARY KEY CLUSTERED 
(
	[log_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PGFUNDOUT]
) ON [PGFUNDOUT]
GO


