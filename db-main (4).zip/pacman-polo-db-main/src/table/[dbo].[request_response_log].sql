--USE [PacmanPoloDB]
--GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[request_response_log](
	[req_resp_id] [bigint] IDENTITY(1,1) NOT NULL,
	[request] [varchar](4000) NOT NULL,
	[response] [nvarchar](MAX) NOT NULL,
	[date_stamp] [datetime] NOT NULL,
	[method] [varchar](100) NOT NULL,
CONSTRAINT [PK_request_response_log] PRIMARY KEY CLUSTERED 
(
	[req_resp_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PGLOG]
) ON [PGLOG]
GO

