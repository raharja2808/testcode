--USE [PacmanPoloDB]
--GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[fundin_history_log](
	[log_id] [bigint] IDENTITY(1,1) NOT NULL,
	[merchant_transaction_id] [varchar](50) NOT NULL,
	[merchant_id] [varchar](50) NOT NULL,
	[pg_merchant_id] [varchar](100) NOT NULL,
	[currency] [varchar](3) NOT NULL,
	[amount] [decimal](18,4) NOT NULL,
	[date_fundin_request] [datetime]  NOT NULL,
	[date_fundin_notify] [datetime]  NOT NULL,
	[pg_transaction_id] [varchar](50) NOT NULL,
	[fundin_status] [varchar](20) NOT NULL,
	[payment_channel_id] [varchar](20) NOT NULL,
	[payment_channel_id_vendor] [varchar](20) NOT NULL,
	[bank_code] [varchar](10) NOT NULL,
	[bank_code_vendor] [varchar](10) NOT NULL,
	[trigger_by] [varchar](20) NOT NULL,
	[transaction_note] [varchar](500) NOT NULL,
CONSTRAINT [PK_fundin_history_log] PRIMARY KEY CLUSTERED 
(
	[log_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PGFUNDIN]
) ON [PGFUNDIN]
GO
