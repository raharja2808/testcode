--USE [PacmanPoloDB]
--GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[master_pg](
	[pg_merchant_id] [varchar](100) NOT NULL,
	[pg_merchant_passkey] [varchar](100) NOT NULL,
	[pg_merchant_payment_channel] [varchar](20) NOT NULL,
	[pg_merchant_payment_channel_vendor] [varchar](20) NOT NULL,
	[pg_merchant_note] [varchar](500) NOT NULL,
	[currency] [varchar](3) NOT NULL,
	[request_url_fund_in] [varchar](1000) NOT NULL,
	[return_url_fund_in] [varchar](1000) NOT NULL,
	[request_url_fund_out] [varchar](1000) NOT NULL,
CONSTRAINT [PK_master_pg] PRIMARY KEY CLUSTERED 
(
	[pg_merchant_id],
	[pg_merchant_payment_channel],
	[pg_merchant_payment_channel_vendor] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [MASTER]
) ON [MASTER]
GO


