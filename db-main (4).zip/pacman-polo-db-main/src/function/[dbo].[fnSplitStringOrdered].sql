--USE [PacmanPoloDB]
--GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER FUNCTION [dbo].[fnSplitStringOrdered]
(
	@value varchar(8000),
    @delimiter varchar(1)
)
RETURNS 
@RetVal TABLE 
(
	rows_number int primary key,
    value varchar(8000)
)
AS
BEGIN

	DECLARE @numbers TABLE(number int primary key);
	DECLARE @step int

	SET @step = 1
	WHILE @step <= LEN(@value)
	BEGIN
		INSERT INTO @numbers(number)
		SELECT @step

		SET @step = @step + 1
	END

	;WITH CTE(idx, val) AS
	(
		SELECT CHARINDEX(@delimiter, @value + @delimiter, number)
			, SUBSTRING(@value, Number, CHARINDEX(@delimiter, @value + @delimiter, Number) - Number)
		FROM @numbers
		WHERE Number <= LEN(@value)
		AND SUBSTRING(@delimiter + @value, Number, LEN(@delimiter)) = @delimiter
	)
    INSERT INTO @RetVal(rows_number, value)
	SELECT ROW_NUMBER() OVER(ORDER BY idx), val
	FROM CTE
    
    RETURN
END
GO
